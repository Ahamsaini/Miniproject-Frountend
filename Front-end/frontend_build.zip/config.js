window.APP_CONFIG = {
    // Replace this with your Cloudflare URL whenever it changes
    API_BASE_URL: 'https://roommates-sunday-discretion-conscious.trycloudflare.com/api'
};
