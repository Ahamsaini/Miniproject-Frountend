window.APP_CONFIG = {
    // Replace this with your Cloudflare URL whenever it changes
    API_BASE_URL: 'https://enable-continuously-constructed-illustration.trycloudflare.com/api'
};
